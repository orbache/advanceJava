/**
 * Create: Evyatar Orbach
 * Date: 07/12/2018
 * Brief: mmn 13 qu 2
 */
package q2;

public class Test {
	public static void main(String[] args) {		
		TriviaFrame window = new TriviaFrame();
	}
}
